xml.xsd downloaded from http://www.w3.org/2001/xml.xsd on 25 January 2008.  
It doesn't validate and may be incomplete.

Bruce Simons