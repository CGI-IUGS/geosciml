The schemas/dtds in this directory were sourced from 
http://www.oasis-open.org/committees/entity/release/1.0/
on 14 November 2006.