This is the GML Application Schema version of the O&M model, per OGC 05-087r3.

Simon Cox - 2006-09-15
