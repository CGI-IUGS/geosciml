2007-07-25  Mike Botts

  * released sensorML 1.0.0 (OGC 07-000), ic 2.0 and sweCommon 1.0.0 (from OGC 07-000)
  * sensorML/1.0.0 (OGC 07-000) references ic/2.0 and sweCommon/1.0.0
  * see ChangeLog.txt for additional details
  
2007-10-22  Simon Cox

   * import sweCommon 1.0.1
   * updated namespace version to 1.0.1

