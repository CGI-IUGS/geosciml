Local schema package that validates under XML Spy v.2005 rel. 3.
Synchronized with GeoSciML v1.1 schema as of 05/15/06 by SMR

Some unused schema still remain in the package (WFS versions, Filter versions...), but need to carefully sort out which of these are referenced elsewhere.

Instance documents mostly validated before v1.1 synchronization, now they need to be overhauled again.

schema modifications:

SMR remove references to smil in C:\aWorkspace\CGI_DataModel\LocalSchema\gml\3.1.1\base\defaultStyle.xsd

SMR <xs:attribute name="isoType" type="xs:string"/> SMR comment out to validate --> in C:\aWorkspace\CGI_DataModel\LocalSchema\iso19139\gml3.1.1version\gco\gcoBase.xsd
