Local schema package that validates under XML Spy v.2005 rel. 3.
Synchronized with GeoSciML v1.1 schema as of 05/15/06 by SMR

Some unused schema still remain in the package (WFS versions, Filter versions...), but need to carefully sort out which of these are referenced elsewhere.

Instance documents mostly validated before v1.1 synchronization, now they need to be overhauled again.

schema modifications:

SMR remove references to smil in C:\aWorkspace\CGI_DataModel\LocalSchema\gml\3.1.1\base\defaultStyle.xsd

SMR <xs:attribute name="isoType" type="xs:string"/> SMR comment out to validate --> in C:\aWorkspace\CGI_DataModel\LocalSchema\iso19139\gml3.1.1version\gco\gcoBase.xsd


Some annotation elements have been removed under the suspicion that these were somehow interfering with validation (based on some discussions on Altova discussion groups); I'm not sure if this helped or not in the end.
Mostly had to comment out/rearrange/or add imports to avoid duplicate definition of elements, particularly xlink stuff. Validation  behavior is not entirely predictable--results will probably vary in your local environment!

steve
