This is version 1.1.0  of GeoSciML.
These documents were copied across from ../1.0.0 on 2006-04/27

The UML Model ./model/GeoSciML.EAP is an Enterprise Architect document.

A free viewer or 30-day trial edition are available from http://www.sparxsystems.com.au/products/ea_downloads.html