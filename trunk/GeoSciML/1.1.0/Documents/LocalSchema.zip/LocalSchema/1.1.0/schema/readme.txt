This is version 1.1.0 of GeoSciML. 
These documents were first copied across from ../../1.0.0 on 2006-04-27

**** Not yet synchronized with changes to the UML model ****
