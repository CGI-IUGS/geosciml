This is a mirror of the schema for which the reference version is in the OWS-3 subversion repository. 

This lightweight metadata schema is provided for interim use with some SWE XML schemas, 
pending the finalisation of the ISO 19139 schema. 

Simon Cox - 2005-06-06
