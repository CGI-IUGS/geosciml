Local schema package that validates under XML Spy v.2005 rel. 3.
Synchronized with GeoSciML v1.1 schema as of 05/15/06 by SMR

Some unused schema still remain in the package (WFS versions, Filter versions...), but need to carefully sort out which of these are referenced elsewhere.

GeoSciML_WFS-basic.xsd is a wfs schema that imports GeoSciML. This should allow inclusion of GeologicFeatures in WFS feature collections, but doesn't validate ?? any ideas??

Various instance documents are included, including some automatically generated template docs from stylus Studio. These all validated against the GeoSciML schema before I did the v1.1 synchronizastion, now they have some minor problems that need to be fixed. Maybe later...

schema modifications:

SMR remove references to smil in C:\aWorkspace\CGI_DataModel\LocalSchema\gml\3.1.1\base\defaultStyle.xsd

SMR <xs:attribute name="isoType" type="xs:string"/> SMR comment out to validate --> in C:\aWorkspace\CGI_DataModel\LocalSchema\iso19139\gml3.1.1version\gco\gcoBase.xsd
