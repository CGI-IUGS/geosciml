This is version 1.1.0 of GeoSciML. 
These documents were first copied across from ../../1.0.0 on 2006-04-27

**** updated by smr for relative references to other schema in the xmml/subversion/trunk directory, and to bring up to version 1.1.0  052106 ****
