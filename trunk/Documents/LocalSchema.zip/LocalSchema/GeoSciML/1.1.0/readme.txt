This is version 1.1.0  of GeoSciML. Local schema in directory structure parallel to xmml/subversion/trunk directory, for offline schema checking and validation. Schema updates by SMR for GeoSciML UML model v. 1.1.0 consistency: 

in geologicFeature (top.xsd)
change classifier type to "gsml:ControlledConceptPropertyType" (was "gml:referenceType")
change alternateClassifier type to "gsml:ControlledConceptPropertyType" (was "gml:referenceType")

geologicUnit.xsd
grosschemistry type change to "gsml:CGI_TermValuePropertyType" (was "gsml:ChemicalCompositionClass")

change element name="LithoStratigraphicUnit" to element name="LithostratigraphicUnit" to match EA UML class name.

minOccurs on LithologicUnit.weatheringCharacter set to "0"
minOccurs on LithostratigraphicUnit.beddingPattern set to "0"
minOccurs on LithostratigraphicUnit.beddingStyle set to "0"
minOccurs on LithostratigraphicUnit.beddingThickness set to "0"
minOccurs on LithostratigraphicUnit.uniThickness set to "0"



EarthMaterial.xsd
grosschemistry type change to "gsml:CGI_TermValuePropertyType" (was "gsml:ChemicalCompositionClass")

*********************

Issues--how to represent ordering of stratigraphic parts in a lithostratigrpahic unit within a feature collection. GeologicRelation is obvious mechanism, but it is not a gml feature, so technically can't include in wfs feature collection.

**********************

These documents were copied across from ../1.0.0 on 2006-04/27

The UML Model ./model/GeoSciML.EAP is an Enterprise Architect document.

A free viewer or 30-day trial edition are available from http://www.sparxsystems.com.au/products/ea_downloads.html