This is the the GML 3.1.1 bugfix release. 

This release has minimal corrections relative to GML 3.1.0 to ensure successful validation by the most common processing tools, in particular Xerces-J and .Net. 
It was endorsed as an Implementation Specification by Open Geospatial Consortium, in May 2005

http://schemas.opengis.net/gml/3.1.1/

SJDC 2005-05-24